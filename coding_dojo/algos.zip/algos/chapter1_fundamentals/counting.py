def counting():    
    for i in range(1,100):
	if i%10 == 0:
	    print "dojo"
	elif i%5 == 0:
	    print "coding"
	else:
	    print i

if __name__ == '__main__':
   counting()  
