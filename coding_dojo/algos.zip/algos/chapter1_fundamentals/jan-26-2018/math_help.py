def mathhelp(b,m):
    newarr=[]
    y=0
    value=float(y-b)/m
    print value
    newarr.append((value))
    newarr.append(0)
    print newarr

if __name__=='__main__':
    mathhelp(2,-4)
