def integers():
    for i in range(1,256):
	print i 
    

if __name__=='__main__':
    integers()
