def soaringiq():
    count=101
    for i in range(1,99):
	count=count+0.1*i
    print count
if __name__=='__main__':
    soaringiq()
