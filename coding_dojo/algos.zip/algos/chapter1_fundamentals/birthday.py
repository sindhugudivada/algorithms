def birthday():
    temp1=06
    temp2="thursday"
    if temp1 == 06 and temp2 == "thursday":
	print "how did you know?"
    else:
	print "Just another day"
    


if __name__ == '__main__':
   birthday()  
