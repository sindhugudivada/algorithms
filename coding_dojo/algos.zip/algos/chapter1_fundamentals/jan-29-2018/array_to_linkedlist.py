class Node:
    def __init__(self,data):
	self.data=data
	self.next=None

    def insert(arr,data):
	for i in arr:
	    current=arr[i]
	    current=current.next
