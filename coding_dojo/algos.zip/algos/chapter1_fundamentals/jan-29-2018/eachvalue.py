def eachvalue(arr):
    for i in range(len(arr)):
	print arr[i]  



if __name__=='__main__':
    eachvalue([1,2,3,4,5,6,7,8,9])
