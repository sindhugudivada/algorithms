def twelve_bar_blues():
    for i in range(1,13):
        print i
	print "chick boom chick"
    

if __name__=='__main__':
    twelve_bar_blues()
