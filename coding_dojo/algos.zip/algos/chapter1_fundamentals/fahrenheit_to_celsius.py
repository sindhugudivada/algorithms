def fahrenheittocelsius(fDegrees):
    fahrenheit = (9/5*fDegrees)+32
    return fahrenheit

if __name__ == '__main__':
   print(fahrenheittocelsius(20))  
