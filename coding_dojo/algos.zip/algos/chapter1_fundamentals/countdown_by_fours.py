def countdown():
    count=2016
    while count>0 :
	print count
	count=count-4


if __name__ == '__main__':
   countdown()  
