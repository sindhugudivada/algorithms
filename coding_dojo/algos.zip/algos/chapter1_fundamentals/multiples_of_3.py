def multiples():
    for x in range(-300,0):
	if (x%3== 0):
	    if (x!=-3 or x!=-6):
		print x,




if __name__ == '__main__':
   multiples()  
