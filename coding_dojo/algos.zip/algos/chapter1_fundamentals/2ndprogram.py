def number():
    for x in range(-52,1067):
	print (x),

if __name__ == '__main__':
   number() 
