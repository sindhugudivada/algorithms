def setting_and_swapping(myNumber,myName):
    temp=myNumber
    myNumber=myName
    myName=temp
    print myNumber
    print myName




if __name__ == '__main__':
   setting_and_swapping(42,"sindhu")  
