def printarr(arr):
    print arr[0]
    return arr[1]

if __name__ == '__main__':
   print(printarr([1,2]))  
