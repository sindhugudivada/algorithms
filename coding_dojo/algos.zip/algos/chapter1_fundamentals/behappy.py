def beCheerful():
    print "good morning"
    

if __name__ == '__main__':
    for _ in range(98):
	    beCheerful()

