def alwayshungry(arr):
    string="food"
    if string in arr:
	print "yummy"
    else:
	print "I'm hungry"



if __name__ == '__main__':
   alwayshungry([2,10,-9,19])  
