def integers():
    print 'my life is in confusion',
    i=5281
    while i>2000:
	print i,
	i=i-1

if __name__ == '__main__':
    integers()  
